import logging
import socket
import struct
import pickle

from typing import Union, Dict, Tuple, List

from ..models.socket import SocketCommand
from ..models.audio import SAMPLE_RATE, TSpeechObject

class PacketManager:
    _data: Dict[socket.socket, bytes]

    def __init__(self, logger: logging.Logger):
        self._logger = logger
        self._data = {}

    def recv_bytes(self, sock: socket.socket, n: int) -> bytes:
        self._data[sock] = b""
        while len(self._data[sock]) < n:
            chunk = sock.recv(n - len(self._data[sock]))
            if not chunk:
                raise ConnectionError("Socket closed from server")
            self._data[sock] += chunk
        return self._data[sock]
    
    # Packing data

    @staticmethod
    def get_listen_command_bytes(t_speech: TSpeechObject) -> bytes:
        return t_speech.toBytes()

    @staticmethod
    def get_play_command_bytes(filename: str) -> bytes:
        return filename.encode()

    @staticmethod
    def get_record_command_bytes(filename: str, duration: float) -> bytes:
        return filename.encode() + b'|' + struct.pack("f", duration)

    @staticmethod
    def get_command(data: bytes):
        return SocketCommand(data[4:5])
    
    @staticmethod
    def pack_command(command: SocketCommand, payload: Union[Dict, List[bytes]]) -> bytes:
        data = pickle.dumps((command.value, payload))
        data_len = len(data).to_bytes(4, byteorder="big", signed=False)
        return data_len + data
    
    # Unpacking Data

    @staticmethod
    def get_record_data(data: bytes):
        filename, duration = data[5:].split(b'|')
        return filename.decode(), struct.unpack("f", duration)[0]

    @staticmethod
    def get_samples_from_seconds(seconds: float) -> float:
        return SAMPLE_RATE * seconds

    @staticmethod
    def get_audio_data(data: bytes):
        return data[5:]

    def unpack_command(self, packet: bytes) -> Tuple[SocketCommand, Union[Dict, List[bytes]]]:
        command, payload = pickle.loads(packet)
        return SocketCommand(command), payload