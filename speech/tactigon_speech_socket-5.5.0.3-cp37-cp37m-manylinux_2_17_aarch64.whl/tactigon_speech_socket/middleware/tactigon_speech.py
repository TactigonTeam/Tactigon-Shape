import time
import logging
import deepspeech
import numpy as np
import wave

from collections import deque
from threading import Thread, Event

# from pyaudio import PyAudio, paContinue
from datetime import datetime
from typing import Optional, List, Generator, Any

from ..models.audio import VoiceConfig, SAMPLE_RATE, SAMPLE_WIDTH, AUDIO_FRAME_LENGTH, N_CHANNELS, HotWord, TSpeech, TSpeechObject, Transcription, TactigonSpeechResponse
from ..models.socket import SocketCommand

def millis():
    return datetime.now()

class TactigonSpeech(Thread):
    _TICK: float = 0.02
    _stop_event: Event
    _writing: Event

    _logger: logging.Logger
    _config: VoiceConfig
    _command: Optional[SocketCommand]
    _payload: dict
    _deque: deque

    _model: deepspeech.Model

    _is_working: bool = False
    _force_stop: bool = False
    _response: Optional[TactigonSpeechResponse] = None
    _transcription: bool = False
    _transcription_end: bool = False

    current_branch: Optional[List[TSpeech]]
    tree_path: List[HotWord]
    stop_hotword: Optional[HotWord]

    def __init__(self, config: VoiceConfig):
        Thread.__init__(self)
        self._stop_event = Event()
        self._writing = Event()
        self._logger = logging.getLogger(TactigonSpeech.__name__)
        self._config = config
        self._command = None
        self.current_branch = None
        self.tree_path = []
        self.stop_hotword = None
        self._audio_buffer = deque()

        self._logger.info("Initializing model %s", self._config.model_full_path)
        self._model = deepspeech.Model(self._config.model_full_path)

        if self._config.scorer_full_path:
            self._logger.info("Configuring scorer %s", self._config.scorer_full_path)
            self._model.enableExternalScorer(self._config.scorer_full_path)
            self._model.setBeamWidth(self._config.beam_width)

        self._logger.info("Model initialized")

    @property
    def command(self) -> Optional[SocketCommand]:
        return self._command
    
    @command.setter
    def command(self, command: SocketCommand):
        self._command = command

    @property
    def payload(self) -> dict:
        return self._payload
    
    @payload.setter
    def payload(self, payload: dict):
        self._payload = payload

    @property
    def is_working(self) -> bool:
        return self._is_working
    
    @property
    def response(self) -> Optional[TactigonSpeechResponse]:
        if self._writing.is_set():
            return None
        
        if self._response and self._response.complete:
            self._is_working = False

        r = self._response
        self._response = None
        return r
    
    @response.setter
    def response(self, response: TactigonSpeechResponse):
        self._logger.debug("Setting response %s", response)
        self._writing.set()
        self._response = response
        self._writing.clear()
    
    def append_audio(self, audio: bytes):
        self._audio_buffer.append(audio)

    def run(self):
        while not self._stop_event.is_set():
            if not self._command:
                time.sleep(0.1)
                continue

            self._logger.debug("Running command %s", self._command)

            self._is_working = True
            self._audio_buffer.clear()

            if self._command == SocketCommand.RECORD:
                self.record(
                    self._payload.get("filename", "temp.wav"), 
                    self._payload.get("seconds", 5)
                )
                self.response = TactigonSpeechResponse(True, {"record": self._payload.get("filename", "temp.wav")})
            elif self._command == SocketCommand.LISTEN:
                self._transcription_end = False
                transcription: Transcription = self.stt(TSpeechObject.FromJSON(self._payload))
                self._transcription_end = True
                self.response = TactigonSpeechResponse(True, {"transcription": transcription.toJSON()})
            else:
                self._logger.warning("Got an unexpected command %s, payload %s", self._command, self._payload)
                self.response = TactigonSpeechResponse(True, {"ack": True})

            self._command = None
            self._payload = {}
    
    def join(self, timeout: Optional[float] = None):
        self._logger.debug("Called stop...")
        self._stop_event.set()
        Thread.join(self, timeout)
        self._logger.info("Joined!")
   
    def frame_collector(self, seconds: Optional[float] = None) -> Generator[bytes, bytes, None]:
        voice_s = seconds if seconds else self._config.voice_timeout
        silence_s = seconds if seconds else self._config.silence_timeout
        frame_length = SAMPLE_WIDTH * SAMPLE_RATE / AUDIO_FRAME_LENGTH
        max_samples_num = frame_length * voice_s
        silence_samples_num = frame_length * silence_s

        frame = b''
        num_frames = 0
        num_frames_after_last_word = 0
        words_found = False

        self._is_timeout = False
        self._force_stop = False
    
        while True:
            if self._force_stop:
                self._logger.info("Forced stop")
                return None
            
            if self._transcription_end:
                self._transcription_end = False
                self._logger.info("Transcription end")
                return None
            
            if num_frames >= max_samples_num:
                self._is_timeout = True
                self._logger.info("Voice timeout")
                return None
            
            if self._transcription:
                self._transcription = False
                words_found = True
                self._logger.debug("Reset silence timeout")
                num_frames_after_last_word = 0
            
            if num_frames_after_last_word >= silence_samples_num:
                self._is_timeout = True
                self._logger.info("Silence timeout")
                return None
            
            if not self._audio_buffer:
                time.sleep(self._TICK)
                continue
        
            frame = self._audio_buffer.popleft()
            num_frames += 1

            if words_found:
                num_frames_after_last_word += 1

            yield frame

    def stop(self):
        self._logger.debug("Forcing stop...")
        self._force_stop = True

    def record(self, filename: str, seconds: float):
        self._logger.info("Recording %s for %s seconds", filename, seconds)
        with wave.open(filename, mode='wb') as wave_file:
            wave_file.setsampwidth(SAMPLE_WIDTH)
            wave_file.setnchannels(N_CHANNELS)
            wave_file.setframerate(SAMPLE_RATE)

            frames = self.frame_collector(seconds)

            for frame in frames:
                if frame is None:
                    break
                wave_file.writeframes(frame)
    
    def stt(self, speech_tree: Optional[TSpeechObject]) -> Transcription:
        text_so_far = ""
        self.tree_path = []

        if speech_tree:
            self.current_branch = speech_tree.t_speech
            self._model.clearHotWords()
        else:
            self.current_branch = None

        self._is_timeout = False
        self._transcription = False
        time_inference = millis()

        stt_stream = self._model.createStream()
        frames = self.frame_collector()
    
        for frame in frames:
            if frame is None:
                break

            if self.current_branch is not None and len(self.current_branch) == 0:
                self._logger.warning("Problem with current branch %s", self.current_branch)
                break

            if self.current_branch:
                self._model.clearHotWords()

                for hw_obj in self.current_branch:
                    for hotword in hw_obj.hotwords:
                        self._model.addHotWord(hotword.word, hotword.boost)
                if self.stop_hotword:
                    self._model.addHotWord(self.stop_hotword.word, self.stop_hotword.boost)

            stt_stream.feedAudioContent(np.frombuffer(frame, dtype='int16'))
            text = stt_stream.intermediateDecode()

            if text != text_so_far:
                self._logger.info("Text so far: %s", text)
                text_so_far = text
                if text_so_far != "":
                    self._transcription = True
                    self.response = TactigonSpeechResponse(False, {"text_so_far": text_so_far})
                if self.current_branch:
                    self.check_branch(text)

        time_inference = (millis()-time_inference).total_seconds()
        text_so_far = stt_stream.finishStream()
        self._logger.info("Transcibed text: %s. Tree path: %s. Inference %f seconds", text_so_far, self.tree_path, time_inference)

        return Transcription(text_so_far, self.tree_path, time_inference, self._is_timeout)

    def check_branch(self, text: str):
        word_list = list(filter(lambda t: len(t) > 1 , text.split(" ")))
        if self.stop_hotword and self.stop_hotword.word in word_list[-2::]:
            self.tree_path.append(self.stop_hotword)
            return

        if self.current_branch:
            for tspeech in self.current_branch:
                for hotword in tspeech.hotwords:
                    if hotword.word in word_list[-2::]:
                        self.tree_path.append(hotword)
                        self.current_branch = tspeech.children.t_speech if tspeech.children else []
                        return
        return